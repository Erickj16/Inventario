package com.example.proyectofin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.proyectofin.databinding.ActivityMainActivity1verproductoBinding
import com.example.proyectofin.databinding.ActivityMainBinding

class MainActivity1VerProducto : AppCompatActivity() {
    private lateinit var binding : ActivityMainActivity1verproductoBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainActivity1verproductoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(findViewById(R.id.verproducto_toolbar))


        supportActionBar?.apply {
            title = "Lista de Producto"
            subtitle = "Inventario"
            setDisplayShowHomeEnabled(true)
            setLogo(R.mipmap.ic_launcher2)
            setDisplayUseLogoEnabled(true)
        }
    }
}