package com.example.proyectofin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.proyectofin.databinding.ActivityMainActivity3editarproductoBinding
import com.example.proyectofin.databinding.ActivityMainBinding

class MainActivity3EditarProducto : AppCompatActivity() {
    private lateinit var binding : ActivityMainActivity3editarproductoBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainActivity3editarproductoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(findViewById(R.id.editarproducto_toolbar))


        supportActionBar?.apply {
            title = "Lista de Producto"
            subtitle = "Inventario"
            setDisplayShowHomeEnabled(true)
            setLogo(R.mipmap.ic_launcher2)
            setDisplayUseLogoEnabled(true)
        }
    }
}