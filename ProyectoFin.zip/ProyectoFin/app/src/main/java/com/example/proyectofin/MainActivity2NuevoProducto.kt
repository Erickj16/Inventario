package com.example.proyectofin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.proyectofin.databinding.ActivityMainActivity2nuevoproductoBinding
import com.example.proyectofin.databinding.ActivityMainBinding

class MainActivity2NuevoProducto : AppCompatActivity() {
    private lateinit var binding : ActivityMainActivity2nuevoproductoBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainActivity2nuevoproductoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(findViewById(R.id.nuevoproducto_toolbar))


        supportActionBar?.apply {
            title = "Nuevo Producto"
            subtitle = "Inventario"
            setDisplayShowHomeEnabled(true)
            setLogo(R.mipmap.ic_launcher2)
            setDisplayUseLogoEnabled(true)
        }
    }
}